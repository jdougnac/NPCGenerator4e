
import random
careers = {
'academic' : ['apothecary','engineer','lawyer','nun','physician','priest','scholar','wizard'],
'burgher':['agitator','artisan','beggar','investigator','merchant','rat catcher','townsman','watchman'],
'courtier':['advisor','artist','duellist','envoy','noble','servant','spy','warden'],
'peasant':['bailiff','hedge witch','herbalist','hunter','miner','mystic','scout','villager'],
'ranger':['bounty hunter','coachman','entertainer','flagellant','messenger','pedlar','road warden','witch hunter'],
'riverfolk':['boatman','huffer','riverwarden','riverwoman','seaman','smuggler','stevedore','wrecker'],
'rogue':['bawd','charlatan','fence','grave robber','outlaw','racketeer','thief','witch'],
'warrior': ['cavalryman','guard','knight','pit fighter','protagonist','soldier','slayer','warrior priest']
}

exclusive_careers = {
    'dwarf': {'warrior':['slayer']},
    'human': {'academic': ['nun','priest'],
              'peasant': ['hedge witch'],
              'ranger': ['flagellant','witch hunter'],
              'rogue': ['witch'],
              'warrior': ['warrior priest']}
}

forbidden_careers = {
    'dwarf': {'academic': ['nun','priest','wizard'],
              'peasant': ['hedge witch','herbalist','mystic'],
              'ranger': ['flagellant','road warden', 'witch hunter'],
              'riverfolk': ['riverwarden'],
              'rogue': ['bawd','charlatan','grave robber','witch'],
              'warrior': ['cavalryman','knight','warrior priest']},

    'halfling': {'academic': ['nun','priest','wizard'],
                 'courtier': ['duellist','noble'],
                 'peasant': ['hedge witch','mystic'],
                 'ranger': ['flagellant','witch hunter'],
                 'riverfolk': ['wrecker'],
                 'rogue': ['witch'],
                 'warrior': ['cavalryman','knight','protagonist','slayer','warrior priest']},

    'high elf': {'academic': ['engineer','nun','priest'],
                 'burgher': ['agitator','beggar','rat catcher'],
                 'courtier': ['servant'],
                 'peasant':['bailiff','hedge witch','miner','mystic','villager'],
                 'ranger': ['coachman','flagellant','pedlar','road warden','witch hunter'],
                 'riverfolk': ['huffer','riverwarden','riverwoman','stevedore','wrecker'],
                 'rogue': ['fence','grave robber','racketeer','thief', 'witch'],
                 'warrior':['slayer','warrior priest']},

    'human': {'warrior':['slayer']},


    'wood elf': {'academic':['apothecary','engineer','lawyer', 'nun','priest','physician'],
                 'burgher':['agitator','beggar','investigator', 'merchant','rat catcher','townsman','watchman'],
                 'courtier': ['duellist','servant','warden'],
                 'peasant': ['bailiff','hedge witch','miner','villager'],
                 'ranger': ['coachman','flagellant','pedlar','road warden','witch hunter'],
                 'riverfolk': ['boatman','huffer','riverwarden','riverwoman','seaman','smuggler','stevedore'],
                 'rogue': ['bawd', 'charlatan','fence','grave robber','racketeer','thief', 'witch'],
                 'warrior': ['protagonist', 'slayer', 'warrior priest']
        }
}



