from NPCGenerator4e.info import career_selection as cs
import copy
import random

def filterCareerBySpecies(species):
    start_careers = copy.deepcopy(cs.careers)
    
    for x in cs.forbidden_careers[species]:       
        for item in cs.forbidden_careers[species][x]:       
            start_careers[x].remove(item)

    return start_careers


def pickCareer(species,gameClass,career):
    careerFiltered = filterCareerBySpecies(species)
    if career != 'random':
        return career
    elif gameClass != 'random':
        finalCareer = random.choice(careerFiltered[gameClass])
        return finalCareer
    else:
        finalClass = random.choice(list(careerFiltered.values()))
        finalCareer = random.choice(finalClass)
        return finalCareer