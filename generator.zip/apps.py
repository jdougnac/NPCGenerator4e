from django.apps import AppConfig


class HammerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'NPCGenerator4e'
