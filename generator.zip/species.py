import random
from NPCGenerator4e.info import species_selection as spec

def assignSpecies(species):
    speciesList = []
    for x in spec.species_dict:
        speciesList.append(x)
    if species == 'random':
        return random.choice(speciesList)
    elif species in speciesList:
        return species
    return 'ERROR'