import random

def a():
    return 1,2

b,c = a()

print(b)
print(c)